package com.sggs;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class getdata
 */
@WebServlet("/getdata")
public class getdata extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getdata() {
		super();
		// TODO Auto-generated constructor stub
	}

	private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/sggs";
	private static final String USER = "root";
	private static final String PASSWORD = "";
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("rawtypes")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		Connection conn = null;
		Statement scmt = null;
		ResultSet rs = null;
		List<Comparable> datalist = new ArrayList<Comparable>();
		

		response.setContentType("text/html");

		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			scmt = conn.createStatement();
			String sql = "SELECT *FROM users";
			rs = scmt.executeQuery(sql);
			PreparedStatement ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {

				datalist.add(rs.getInt("id"));
				datalist.add(rs.getString("First name"));
				datalist.add(rs.getString("Last Name"));
				datalist.add(rs.getString("userId"));
				datalist.add(rs.getString("Gender"));
				datalist.add(rs.getString("created_at"));
				datalist.add(rs.getString("status"));
				datalist.add(rs.getString("Question"));

			}
			rs.close();
			ps.close();

			request.setAttribute("data", datalist);
			request.getRequestDispatcher("show.jsp").forward(request, response);
			//response.sendRedirect("show.jsp");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}

	}

}
