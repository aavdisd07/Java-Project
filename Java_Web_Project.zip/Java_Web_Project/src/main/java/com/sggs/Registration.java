package com.sggs;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.mysql.cj.xdevapi.Statement;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/sggs";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = null;
		Statement scmt = null;
		ResultSet rs = null;

		try {
			// Register JDBC Driver
			Class.forName(JDBC_DRIVER);
			// Open a Connection

			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);

			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String password = request.getParameter("password");
			String gender = request.getParameter("gender");
			String userid = request.getParameter("userid");
			String phone = request.getParameter("phone");
			String question = request.getParameter("question");
			String Qans = request.getParameter("Qans");
			scmt = conn.createStatement();
			String sql = "INSERT INTO `users`( `First name`, `Last Name`, `Password`, `userId`,"
					+ " `phone`, `Question`, `Qans`," + " `Gender`) VALUES('" + fname + "','" + lname + "','" + password
					+ "','" + phone + "','" + userid + "','" + question + "','" + Qans + "','" + gender + "')";
			int rows = scmt.executeUpdate(sql);

			if (rows > 0) {
				response.sendRedirect("success.jsp");

			} else {
				response.sendRedirect("error.jsp");
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("In catch block" + e.toString());
		}

	}

}
