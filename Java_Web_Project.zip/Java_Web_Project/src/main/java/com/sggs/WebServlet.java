package com.sggs;

public @interface WebServlet {

}
